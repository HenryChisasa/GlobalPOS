require('./assets/js/pos.js');
require('./assets/js/product-filter.js');
require('print-js');